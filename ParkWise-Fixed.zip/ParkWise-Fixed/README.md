# ParkWise

Run `npm install` then `npm run dev` in this folder. Open the Vite localhost URL. This is a frontend demo using React state; refresh resets the demo parking data.