
import { useState } from "react";
import "./style.css";

const initialSlots = [
  { id: "A01", status: "occupied", type: "EV", car: "Tesla Model 3" },
  { id: "A02", status: "available", type: "Regular" },
  { id: "A03", status: "available", type: "Regular" },
  { id: "A04", status: "reserved", type: "Accessible" },
  { id: "A05", status: "occupied", type: "Regular", car: "Hyundai Creta" },
  { id: "A06", status: "available", type: "EV" },
  { id: "B01", status: "available", type: "Regular" },
  { id: "B02", status: "occupied", type: "Regular", car: "Honda City" },
  { id: "B03", status: "available", type: "Accessible" },
  { id: "B04", status: "available", type: "Regular" },
  { id: "B05", status: "reserved", type: "EV" },
  { id: "B06", status: "available", type: "Regular" },
  { id: "C01", status: "occupied", type: "Regular", car: "Kia Seltos" },
  { id: "C02", status: "available", type: "EV" },
  { id: "C03", status: "available", type: "Regular" },
  { id: "C04", status: "available", type: "Regular" },
  { id: "C05", status: "occupied", type: "Regular", car: "Tata Nexon" },
  { id: "C06", status: "available", type: "Accessible" },
];

function App() {
  const [slots, setSlots] = useState(initialSlots);
  const [vehicle, setVehicle] = useState("Car");
  const [filter, setFilter] = useState("all");
  const [allocated, setAllocated] = useState(null);
  const [message, setMessage] = useState("");

  const available = slots.filter(s => s.status === "available").length;
  const occupied = slots.filter(s => s.status === "occupied").length;
  const reserved = slots.filter(s => s.status === "reserved").length;
  const occupancy = Math.round((occupied / slots.length) * 100);

  function allocateSlot() {
    const suitable = slots.find(s =>
      s.status === "available" &&
      (vehicle !== "EV" || s.type === "EV" || s.type === "Regular")
    );

    if (!suitable) {
      setMessage("No suitable parking slot is currently available.");
      setAllocated(null);
      return;
    }

    setSlots(current => current.map(s =>
      s.id === suitable.id
        ? {
    ...s,
    status: "occupied",
    car: vehicle + " vehicle",
    vehicleType: vehicle
  }
        : s
    ));

    setAllocated(suitable.id);
    setMessage(`Your vehicle has been allocated to slot ${suitable.id}.`);
  }

  function releaseSlot(id) {
    setSlots(current => current.map(s =>
      s.id === id
        ? { ...s, status: "available", car: undefined }
        : s
    ));
    if (allocated === id) setAllocated(null);
    setMessage(`Slot ${id} is now available.`);
  }

  const visibleSlots = slots.filter(s =>
    filter === "all" || s.status === filter
  );

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-icon">P</div>
          <div>
            <strong>PARKNEX</strong>
            <span>SMART MOBILITY</span>
          </div>
        </div>

        <div className="side-label">WORKSPACE</div>
        <nav>
          <a className="nav-item active" href="#overview"><span>▦</span> Overview</a>
          <a className="nav-item" href="#parking"><span>▤</span> Parking map</a>
          <a className="nav-item" href="#allocation"><span>⌖</span> Allocation</a>
          <a className="nav-item" href="#activity"><span>◷</span> Activity</a>
        </nav>

        <div className="sidebar-bottom">
          <div className="system-card">
            <div className="system-top"><span className="pulse-dot" /> SYSTEM ONLINE</div>
            <p>All parking systems are running smoothly.</p>
            <div className="system-line"><span /></div>
            <small>System health <b>98.6%</b></small>
          </div>
          <div className="profile">
            <div className="avatar">PN</div>
            <div><strong>Parking Admin</strong><span>Administrator</span></div>
            <span className="profile-dots">•••</span>
          </div>
        </div>
      </aside>

      <main className="main-content" id="overview">
        <header className="topbar">
          <div className="breadcrumb">Workspace <span>/</span> Overview</div>
          <div className="top-actions">
            <div className="live-indicator"><span className="pulse-dot" /> LIVE SYSTEM</div>
            <button className="icon-button" aria-label="Notifications">♧</button>
            <div className="top-date">30 OCT 2026</div>
          </div>
        </header>

        <section className="welcome-row">
          <div>
            <div className="eyebrow"><span /> INTELLIGENT PARKING PLATFORM</div>
            <h1>Parking, <span>reimagined.</span></h1>
            <p className="subtitle">A smarter way to manage every space. Monitor, allocate and optimize your parking lot.</p>
          </div>
          <div className="location-chip"><span>⌖</span><div><small>LOCATION</small><strong>Central Parking Hub</strong></div></div>
        </section>

        <section className="stats-grid">
          <div className="stat-card">
            <div className="stat-heading">TOTAL CAPACITY <span className="stat-icon blue">▦</span></div>
            <div className="stat-number">{slots.length}<small> slots</small></div>
            <div className="stat-foot">Across all parking zones</div>
          </div>
          <div className="stat-card">
            <div className="stat-heading">AVAILABLE SPACES <span className="stat-icon green">⌖</span></div>
            <div className="stat-number green-text">{available}<small> slots</small></div>
            <div className="stat-foot"><span className="mini-dot green-bg" /> Ready for allocation</div>
          </div>
          <div className="stat-card">
            <div className="stat-heading">OCCUPIED SPACES <span className="stat-icon orange">▣</span></div>
            <div className="stat-number">{occupied}<small> slots</small></div>
            <div className="stat-foot">Currently in use</div>
          </div>
          <div className="stat-card">
            <div className="stat-heading">OCCUPANCY RATE <span className="stat-icon purple">◉</span></div>
            <div className="stat-number">{occupancy}<small>%</small></div>
            <div className="progress-track"><span style={{ width: `${occupancy}%` }} /></div>
          </div>
        </section>

        <section className="content-grid">
          <div className="panel parking-panel" id="parking">
            <div className="panel-heading">
              <div>
                <div className="section-kicker">LIVE VISUALIZATION</div>
                <h2>Parking overview</h2>
                <p>Explore the current status of every parking slot.</p>
              </div>
              <div className="zone-select">ZONE A — C <span>⌄</span></div>
            </div>

            <div className="parking-visual">
              <div className="road-label"><span>↑</span> ENTRANCE / MAIN DRIVEWAY <span>↑</span></div>
              <div className="parking-grid">
                {visibleSlots.map(slot => (
                  <div className={`slot ${slot.status}`} key={slot.id}>
                    <div className="slot-top"><span>{slot.id}</span><span className="slot-light" /></div>
                    <div className="car-symbol">
  {slot.status === "occupied"
    ? slot.vehicleType === "Bike"
      ? "🏍️"
      : slot.vehicleType === "EV"
        ? "⚡"
        : "🚘"
    : slot.status === "reserved"
      ? "P"
      : "＋"}
</div>
                    <div className="slot-bottom">
                      {slot.status === "occupied" ? "OCCUPIED" : slot.status === "reserved" ? "RESERVED" : "AVAILABLE"}
                    </div>
                    {slot.status === "occupied" && (
                      <button className="release-button" onClick={() => releaseSlot(slot.id)}>Release</button>
                    )}
                  </div>
                ))}
              </div>
              <div className="road-label exit-road">EXIT LANE <span>→</span></div>
            </div>

            <div className="map-legend">
              <span><i className="legend-dot available-dot" /> Available <b>{available}</b></span>
              <span><i className="legend-dot occupied-dot" /> Occupied <b>{occupied}</b></span>
              <span><i className="legend-dot reserved-dot" /> Reserved <b>{reserved}</b></span>
            </div>
            <div className="filter-row">
              <span>FILTER SLOTS</span>
              {["all", "available", "occupied", "reserved"].map(item => (
                <button key={item} onClick={() => setFilter(item)} className={filter === item ? "filter-active" : ""}>
                  {item === "all" ? "All slots" : item}
                </button>
              ))}
            </div>
          </div>

          <div className="right-column">
            <div className="panel allocation-panel" id="allocation">
              <div className="section-kicker">SMART ALLOCATION</div>
              <h2>Find your space.</h2>
              <p className="panel-description">Let the system find the most suitable parking slot for your vehicle.</p>

              <label className="field-label">SELECT VEHICLE TYPE</label>
              <div className="vehicle-options">
                {[
                  { name: "Car", icon: "🚘" },
                  { name: "Bike", icon: "🏍️" },
                  { name: "EV", icon: "⚡" }
                ].map(v => (
                  <button key={v.name} className={`vehicle-option ${vehicle === v.name ? "vehicle-selected" : ""}`} onClick={() => setVehicle(v.name)}>
                    <span>{v.icon}</span><b>{v.name}</b>
                  </button>
                ))}
              </div>

              <div className="allocation-info">
                <div><span className="info-icon">✦</span><span>Smart slot matching</span><b>ON</b></div>
                <div><span className="info-icon">⌖</span><span>Nearest available slot</span><b>ON</b></div>
              </div>

              <button className="allocate-button" onClick={allocateSlot}>Find My Parking Slot <span>↗</span></button>
              {message && <div className={`result-message ${allocated ? "success" : ""}`}>{message}</div>}
              {allocated && <div className="allocated-card"><span>YOUR ASSIGNED SLOT</span><strong>{allocated}</strong><small>Proceed to your allocated space.</small></div>}
              <div className="allocation-note">Powered by intelligent slot allocation</div>
            </div>

            <div className="panel activity-panel" id="activity">
              <div className="activity-heading"><div><div className="section-kicker">PARKING INSIGHTS</div><h2>Zone performance</h2></div><span className="activity-icon">⌁</span></div>
              {["Zone A", "Zone B", "Zone C"].map((zone, index) => {
                const group = slots.filter(s => s.id.startsWith(String.fromCharCode(65 + index)));
                const used = group.filter(s => s.status !== "available").length;
                return <div className="zone-row" key={zone}>
                  <div><span>{zone}</span><b>{used}/{group.length} used</b></div>
                  <div className="zone-track"><span style={{ width: `${used / group.length * 100}%` }} /></div>
                </div>;
              })}
              <div className="insight-footer"><span className="pulse-dot" /> Live slot status updates</div>
            </div>
          </div>
        </section>

        <footer className="footer"><span>© 2026 PARKNEX SMART PARKING</span><span>DESIGNED FOR SMARTER CITIES <b>✦</b></span></footer>
      </main>
    </div>
  );
}

export default App;
