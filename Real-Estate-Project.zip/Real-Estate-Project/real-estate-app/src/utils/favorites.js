const STORAGE_KEY = "estateLy_favorites";

export const getFavorites = () => {
  return JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];
};

export const isFavorite = (propertyId) => {
  const favorites = getFavorites();
  return favorites.includes(Number(propertyId));
};

export const toggleFavorite = (propertyId) => {
  const id = Number(propertyId);
  const favorites = getFavorites();

  if (favorites.includes(id)) {
    const updatedFavorites = favorites.filter(
      (item) => item !== id
    );

    localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify(updatedFavorites)
    );

    return false;
  }

  const updatedFavorites = [...favorites, id];

  localStorage.setItem(
    STORAGE_KEY,
    JSON.stringify(updatedFavorites)
  );

  return true;
};