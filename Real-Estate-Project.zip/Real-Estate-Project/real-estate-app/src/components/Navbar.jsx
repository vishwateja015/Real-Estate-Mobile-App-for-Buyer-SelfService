import { useEffect, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import {
  Search,
  UserRound,
  LogOut,
  LayoutDashboard,
  ChevronDown,
  X
} from "lucide-react";

function Navbar() {
  const location = useLocation();
  const navigate = useNavigate();

  const [loggedIn, setLoggedIn] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchText, setSearchText] = useState("");

  useEffect(() => {
    const userId = localStorage.getItem("userId");
    setLoggedIn(!!userId);
  }, [location.pathname]);

  const handleLogout = () => {
    localStorage.removeItem("userId");
    localStorage.removeItem("token");
    localStorage.removeItem("user");

    setLoggedIn(false);

    navigate("/login");
  };

  const handleSearch = (e) => {
    e.preventDefault();

    const query = searchText.trim();

    if (!query) {
      return;
    }

    setSearchOpen(false);

    navigate(`/properties?search=${encodeURIComponent(query)}`);
  };

  const hideNavbar =
    location.pathname.startsWith("/property/") ||
    location.pathname === "/login" ||
    location.pathname === "/register";

  if (hideNavbar) {
    return null;
  }

  const isHome = location.pathname === "/";

  return (
    <nav
      className={`navbar ${
        isHome ? "navbar-home" : "navbar-light"
      }`}
    >
      <div className="navbar-container">

        <Link
          to="/"
          className="navbar-logo"
        >
          Estatel<span>y</span>
        </Link>

        <div className="navbar-links">

          <Link
            to="/"
            className={location.pathname === "/" ? "active" : ""}
          >
            Home
          </Link>

          <Link
            to="/properties"
            className={
              location.pathname === "/properties"
                ? "active"
                : ""
            }
          >
            Properties
          </Link>

          <Link
            to="/wishlist"
            className={
              location.pathname === "/wishlist"
                ? "active"
                : ""
            }
          >
            Wishlist
          </Link>

          <Link
            to="/about"
            className={
              location.pathname === "/about"
                ? "active"
                : ""
            }
          >
            About
          </Link>

        </div>

        <div className="navbar-actions">

          {searchOpen ? (
            <form
              className="navbar-search-form"
              onSubmit={handleSearch}
            >

              <Search size={19} />

              <input
                type="text"
                placeholder="Search properties..."
                value={searchText}
                onChange={(e) => setSearchText(e.target.value)}
                autoFocus
              />

              <button
                type="button"
                className="navbar-search-close"
                onClick={() => {
                  setSearchOpen(false);
                  setSearchText("");
                }}
              >
                <X size={18} />
              </button>

            </form>
          ) : (
            <button
              className="navbar-search"
              type="button"
              aria-label="Search properties"
              onClick={() => setSearchOpen(true)}
            >
              <Search size={20} />
            </button>
          )}

          {loggedIn ? (

            <div className="profile-dropdown">

              <button
                type="button"
                className="profile-button"
              >
                <UserRound size={17} />

                <span>
                  Profile
                </span>

                <ChevronDown
                  size={15}
                  className="profile-chevron"
                />
              </button>

              <div className="profile-menu">

                <Link
                  to="/dashboard"
                  className="profile-menu-item"
                >
                  <LayoutDashboard size={17} />

                  <span>
                    Dashboard
                  </span>
                </Link>

                <button
                  type="button"
                  className="profile-menu-item profile-logout"
                  onClick={handleLogout}
                >
                  <LogOut size={17} />

                  <span>
                    Logout
                  </span>
                </button>

              </div>

            </div>

          ) : (

            <Link
              to="/login"
              className="navbar-login"
            >
              <UserRound size={17} />

              <span>
                Login
              </span>
            </Link>

          )}

        </div>

      </div>
    </nav>
  );
}

export default Navbar;