import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";

import {
  Home,
  Heart,
  CalendarDays,
  Eye,
  User,
  Settings,
  LogOut,
  ChevronRight,
  MapPin,
  BedDouble,
  Bath,
  Maximize,
  Clock,
  CheckCircle2,
  X,
  Lock,
  Mail,
  Bell
} from "lucide-react";

import "./Dashboard.css";

function Dashboard() {
  const navigate = useNavigate();

  const userId = localStorage.getItem("userId");

  let storedUser = {};

  try {
    storedUser = JSON.parse(
      localStorage.getItem("user") || "{}"
    );
  } catch {
    storedUser = {};
  }

  const userName = storedUser.name || "User";

  const initials = userName
    .split(" ")
    .map((word) => word[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();

  const [savedProperties, setSavedProperties] = useState([]);
  const [visits, setVisits] = useState([]);
  const [viewedCount, setViewedCount] = useState(0);
  const [selectedVisit, setSelectedVisit] = useState(null);
  const [loading, setLoading] = useState(true);
  const [currentTime, setCurrentTime] = useState(new Date());

  const [showSecurity, setShowSecurity] = useState(false);
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [passwordLoading, setPasswordLoading] = useState(false);

  const [showNotifications, setShowNotifications] = useState(false);

  const [notificationPreferences, setNotificationPreferences] = useState({
    visitConfirmations: true,
    newPropertyAlerts: true,
    wishlistUpdates: true,
    visitReminders: true
  });

  const [notificationSaving, setNotificationSaving] = useState(false);

  const demoLocations = {
    1: {
      address: "Demo Villa, Gachibowli, Hyderabad",
      lat: 17.4401,
      lng: 78.3489
    },
    2: {
      address: "Demo Apartment, Hitech City, Hyderabad",
      lat: 17.4483,
      lng: 78.3915
    },
    3: {
      address: "Demo Family Home, Kondapur, Hyderabad",
      lat: 17.4587,
      lng: 78.3656
    }
  };

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 30000);

    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (!userId) {
      navigate("/login");
      return;
    }

    const loadDashboard = async () => {
      try {
        setLoading(true);

        const [
          favoritesResponse,
          visitsResponse,
          viewResponse
        ] = await Promise.all([
          fetch(
            `http://localhost:5000/api/favorites/${userId}`
          ),
          fetch(
            `http://localhost:5000/api/visits/${userId}`
          ),
          fetch(
            `http://localhost:5000/api/property-views/${userId}/count`
          )
        ]);

        if (favoritesResponse.ok) {
          const favoritesData =
            await favoritesResponse.json();

          setSavedProperties(favoritesData);
        }

        if (visitsResponse.ok) {
          const visitsData =
            await visitsResponse.json();

          setVisits(visitsData);
        }

        if (viewResponse.ok) {
          const viewData =
            await viewResponse.json();

          setViewedCount(
            Number(viewData.count) || 0
          );
        }
      } catch (error) {
        console.error(
          "Failed to load dashboard:",
          error
        );
      } finally {
        setLoading(false);
      }
    };

    loadDashboard();
  }, [userId, navigate]);

  useEffect(() => {
    if (!userId) {
      return;
    }

    const savedPreferences = localStorage.getItem(
      `estateLy_notification_preferences_${userId}`
    );

    if (savedPreferences) {
      try {
        setNotificationPreferences({
          visitConfirmations: true,
          newPropertyAlerts: true,
          wishlistUpdates: true,
          visitReminders: true,
          ...JSON.parse(savedPreferences)
        });
      } catch {
        setNotificationPreferences({
          visitConfirmations: true,
          newPropertyAlerts: true,
          wishlistUpdates: true,
          visitReminders: true
        });
      }
    }
  }, [userId]);

  const upcomingVisits = visits.filter((visit) => {
    if (!visit.visit_date || !visit.visit_time) {
      return false;
    }

    const datePart = String(visit.visit_date).split("T")[0];
    const timePart = String(visit.visit_time).slice(0, 8);

    const visitDateTime = new Date(
      datePart + "T" + timePart
    );

    if (Number.isNaN(visitDateTime.getTime())) {
      return false;
    }

    return visitDateTime > currentTime;
  });

  const handleLogout = () => {
    localStorage.removeItem("userId");
    localStorage.removeItem("token");
    localStorage.removeItem("user");

    navigate("/login");
  };

  const handleOpenSecurity = () => {
    setCurrentPassword("");
    setNewPassword("");
    setConfirmPassword("");
    setShowSecurity(true);
  };

  const handleCloseSecurity = () => {
    if (passwordLoading) {
      return;
    }

    setShowSecurity(false);
    setCurrentPassword("");
    setNewPassword("");
    setConfirmPassword("");
  };

  const handleChangePassword = async (e) => {
    e.preventDefault();

    if (
      !currentPassword ||
      !newPassword ||
      !confirmPassword
    ) {
      alert("Please fill in all password fields.");
      return;
    }

    if (newPassword.length < 6) {
      alert(
        "New password must contain at least 6 characters."
      );
      return;
    }

    if (newPassword !== confirmPassword) {
      alert("New passwords do not match.");
      return;
    }

    try {
      setPasswordLoading(true);

      const response = await fetch(
        "http://localhost:5000/api/auth/change-password",
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${localStorage.getItem(
              "token"
            )}`
          },
          body: JSON.stringify({
            user_id: userId,
            current_password: currentPassword,
            new_password: newPassword
          })
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.message ||
            "Failed to change password."
        );
      }

      alert("Password changed successfully.");

      setShowSecurity(false);
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
    } catch (error) {
      console.error(
        "Password change error:",
        error
      );

      alert(
        error.message ||
          "Unable to change password."
      );
    } finally {
      setPasswordLoading(false);
    }
  };

  const handleOpenNotifications = () => {
    const savedPreferences = localStorage.getItem(
      `estateLy_notification_preferences_${userId}`
    );

    if (savedPreferences) {
      try {
        setNotificationPreferences({
          visitConfirmations: true,
          newPropertyAlerts: true,
          wishlistUpdates: true,
          visitReminders: true,
          ...JSON.parse(savedPreferences)
        });
      } catch {
        setNotificationPreferences({
          visitConfirmations: true,
          newPropertyAlerts: true,
          wishlistUpdates: true,
          visitReminders: true
        });
      }
    }

    setShowNotifications(true);
  };

  const handleCloseNotifications = () => {
    if (notificationSaving) {
      return;
    }

    setShowNotifications(false);
  };

  const handleNotificationChange = (key) => {
    setNotificationPreferences((previous) => ({
      ...previous,
      [key]: !previous[key]
    }));
  };

  const handleSaveNotifications = (e) => {
    e.preventDefault();

    try {
      setNotificationSaving(true);

      localStorage.setItem(
        `estateLy_notification_preferences_${userId}`,
        JSON.stringify(notificationPreferences)
      );

      alert(
        "Email notification preferences saved successfully."
      );

      setShowNotifications(false);
    } catch (error) {
      console.error(
        "Notification settings error:",
        error
      );

      alert(
        "Unable to save notification preferences."
      );
    } finally {
      setNotificationSaving(false);
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) {
      return "";
    }

    const date = new Date(dateString);

    return date.toLocaleDateString("en-IN", {
      day: "numeric",
      month: "short",
      year: "numeric"
    });
  };

  const formatTime = (timeString) => {
    if (!timeString) {
      return "";
    }

    const [hours, minutes] = timeString
      .split(":")
      .map(Number);

    const date = new Date();

    date.setHours(hours);
    date.setMinutes(minutes);

    return date.toLocaleTimeString("en-IN", {
      hour: "numeric",
      minute: "2-digit"
    });
  };

  if (loading) {
    return (
      <div className="dashboard-loading">
        <div className="loading-spinner"></div>

        <p>
          Loading your dashboard...
        </p>
      </div>
    );
  }

  return (
    <div className="dashboard-page">
      <aside className="dashboard-sidebar">
        <div className="dashboard-brand">
          <Link to="/">
            Estatel<span>y</span>
          </Link>
        </div>

        <nav className="dashboard-nav">
          <Link
            to="/dashboard"
            className="dashboard-nav-item active"
          >
            <Home size={19} />
            <span>Dashboard</span>
          </Link>

          <Link
            to="/properties"
            className="dashboard-nav-item"
          >
            <Home size={19} />
            <span>Properties</span>
          </Link>

          <Link
            to="/wishlist"
            className="dashboard-nav-item"
          >
            <Heart size={19} />
            <span>Wishlist</span>
          </Link>

          <a
            href="#visits"
            className="dashboard-nav-item"
          >
            <CalendarDays size={19} />
            <span>My Visits</span>
          </a>

          <a
            href="#profile"
            className="dashboard-nav-item"
          >
            <User size={19} />
            <span>Profile</span>
          </a>

          <a
            href="#settings"
            className="dashboard-nav-item"
          >
            <Settings size={19} />
            <span>Settings</span>
          </a>
        </nav>

        <button
          className="dashboard-logout"
          onClick={handleLogout}
        >
          <LogOut size={19} />
          <span>Logout</span>
        </button>
      </aside>

      <main className="dashboard-main">
        <header className="dashboard-header">
          <div>
            <p className="dashboard-welcome">
              Welcome back,
            </p>

            <h1>{userName}</h1>

            <p className="dashboard-subtitle">
              Here's what's happening with your properties.
            </p>
          </div>

          <div className="dashboard-user">
            <div className="dashboard-avatar">
              {initials}
            </div>

            <div>
              <strong>{userName}</strong>
              <span>Property Buyer</span>
            </div>
          </div>
        </header>

        <section className="dashboard-stats">
          <div className="dashboard-stat-card">
            <div className="dashboard-stat-icon">
              <Heart size={22} />
            </div>

            <div>
              <span>Saved Properties</span>

              <strong>
                {savedProperties.length}
              </strong>
            </div>
          </div>

          <div className="dashboard-stat-card">
            <div className="dashboard-stat-icon">
              <CalendarDays size={22} />
            </div>

            <div>
              <span>Upcoming Visits</span>

              <strong>
                {upcomingVisits.length}
              </strong>
            </div>
          </div>

          <div className="dashboard-stat-card">
            <div className="dashboard-stat-icon">
              <Eye size={22} />
            </div>

            <div>
              <span>Properties Viewed</span>

              <strong>
                {viewedCount}
              </strong>
            </div>
          </div>
        </section>

        <section className="dashboard-section">
          <div className="dashboard-section-header">
            <div>
              <span className="dashboard-label">
                QUICK ACTIONS
              </span>

              <h2>
                What would you like to do?
              </h2>
            </div>
          </div>

          <div className="dashboard-quick-actions">
            <Link
              to="/properties"
              className="dashboard-action-card"
            >
              <div className="dashboard-action-icon">
                <Home size={22} />
              </div>

              <div>
                <h3>
                  Browse Properties
                </h3>

                <p>
                  Explore available properties.
                </p>
              </div>

              <ChevronRight size={19} />
            </Link>

            <Link
              to="/wishlist"
              className="dashboard-action-card"
            >
              <div className="dashboard-action-icon">
                <Heart size={22} />
              </div>

              <div>
                <h3>
                  View Wishlist
                </h3>

                <p>
                  Check your saved properties.
                </p>
              </div>

              <ChevronRight size={19} />
            </Link>

            <a
              href="#visits"
              className="dashboard-action-card"
            >
              <div className="dashboard-action-icon">
                <CalendarDays size={22} />
              </div>

              <div>
                <h3>
                  Manage Visits
                </h3>

                <p>
                  View your scheduled visits.
                </p>
              </div>

              <ChevronRight size={19} />
            </a>
          </div>
        </section>

        <section
          className="dashboard-section"
          id="visits"
        >
          <div className="dashboard-section-header">
            <div>
              <span className="dashboard-label">
                SCHEDULED VISITS
              </span>

              <h2>
                Upcoming visits
              </h2>
            </div>
          </div>

          {upcomingVisits.length === 0 ? (
            <div className="dashboard-empty">
              <CalendarDays size={38} />

              <h3>
                No visits scheduled
              </h3>

              <p>
                Schedule a property visit to see it here.
              </p>

              <Link
                to="/properties"
                className="dashboard-primary-button"
              >
                Browse Properties
              </Link>
            </div>
          ) : (
            <div className="dashboard-visits">
              {upcomingVisits.map((visit) => {
                const isSelected =
                  selectedVisit?.id === visit.id;

                const demoLocation =
                  demoLocations[visit.property_id] || {
                    address: visit.location,
                    lat: 17.4401,
                    lng: 78.3489
                  };

                const mapUrl =
                  `https://www.google.com/maps/search/?api=1&query=${demoLocation.lat},${demoLocation.lng}`;

                const embedUrl =
                  `https://www.google.com/maps?q=${demoLocation.lat},${demoLocation.lng}&output=embed`;

                return (
                  <div
                    className={`dashboard-visit-wrapper ${
                      isSelected ? "selected" : ""
                    }`}
                    key={visit.id}
                  >
                    <button
                      type="button"
                      className="dashboard-visit-card"
                      onClick={() =>
                        setSelectedVisit(
                          isSelected
                            ? null
                            : visit
                        )
                      }
                    >
                      <div className="dashboard-visit-image">
                        <img
                          src={visit.image}
                          alt={visit.title}
                        />
                      </div>

                      <div className="dashboard-visit-info">
                        <h3>
                          {visit.title}
                        </h3>

                        <p className="dashboard-location">
                          <MapPin size={16} />
                          {demoLocation.address}
                        </p>

                        <div className="dashboard-visit-details">
                          <span>
                            <CalendarDays size={15} />
                            {formatDate(
                              visit.visit_date
                            )}
                          </span>

                          <span>
                            <Clock size={15} />
                            {formatTime(
                              visit.visit_time
                            )}
                          </span>
                        </div>
                      </div>

                      <div className="dashboard-visit-status">
                        <span>
                          <CheckCircle2 size={15} />
                          {visit.status || "Pending"}
                        </span>
                      </div>
                    </button>

                    {isSelected && (
                      <div className="dashboard-visit-expanded">
                        <div className="dashboard-visit-expanded-info">
                          <div className="visit-detail-item">
                            <MapPin size={19} />

                            <div>
                              <small>
                                LOCATION
                              </small>

                              <strong>
                                {demoLocation.address}
                              </strong>
                            </div>
                          </div>

                          <div className="visit-detail-item">
                            <CalendarDays size={19} />

                            <div>
                              <small>
                                VISIT DATE
                              </small>

                              <strong>
                                {formatDate(
                                  visit.visit_date
                                )}
                              </strong>
                            </div>
                          </div>

                          <div className="visit-detail-item">
                            <Clock size={19} />

                            <div>
                              <small>
                                VISIT TIME
                              </small>

                              <strong>
                                {formatTime(
                                  visit.visit_time
                                )}
                              </strong>
                            </div>
                          </div>

                          <a
                            href={mapUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="dashboard-map-button"
                            onClick={(event) =>
                              event.stopPropagation()
                            }
                          >
                            <MapPin size={17} />
                            Open in Google Maps
                          </a>
                        </div>

                        <div className="dashboard-map">
                          <iframe
                            src={embedUrl}
                            title={`Map for ${visit.title}`}
                            loading="lazy"
                            allowFullScreen
                          ></iframe>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </section>

        <section className="dashboard-section">
          <div className="dashboard-section-header">
            <div>
              <span className="dashboard-label">
                YOUR COLLECTION
              </span>

              <h2>
                Saved properties
              </h2>
            </div>

            {savedProperties.length > 0 && (
              <Link
                to="/wishlist"
                className="dashboard-view-all"
              >
                View all
                <ChevronRight size={17} />
              </Link>
            )}
          </div>

          {savedProperties.length === 0 ? (
            <div className="dashboard-empty">
              <Heart size={38} />

              <h3>
                Your wishlist is empty
              </h3>

              <p>
                Save properties you love and they will
                appear here.
              </p>

              <Link
                to="/properties"
                className="dashboard-primary-button"
              >
                Explore Properties
              </Link>
            </div>
          ) : (
            <div className="dashboard-property-grid">
              {savedProperties
                .slice(0, 3)
                .map((property) => (
                  <Link
                    to={`/property/${property.id}`}
                    className="dashboard-property-card"
                    key={property.id}
                  >
                    <div className="dashboard-property-image">
                      <img
                        src={property.image}
                        alt={property.title}
                      />

                      <span>
                        {property.type}
                      </span>
                    </div>

                    <div className="dashboard-property-content">
                      <h3>
                        {property.title}
                      </h3>

                      <p className="dashboard-location">
                        <MapPin size={15} />
                        {property.location}
                      </p>

                      <strong className="dashboard-property-price">
                        {property.price}
                      </strong>

                      <div className="dashboard-property-meta">
                        <span>
                          <BedDouble size={15} />
                          {property.bedrooms} Beds
                        </span>

                        <span>
                          <Bath size={15} />
                          {property.bathrooms} Baths
                        </span>

                        <span>
                          <Maximize size={15} />
                          {property.area}
                        </span>
                      </div>
                    </div>
                  </Link>
                ))}
            </div>
          )}
        </section>

        <section
          className="dashboard-section"
          id="profile"
        >
          <div className="dashboard-section-header">
            <div>
              <span className="dashboard-label">
                ACCOUNT
              </span>

              <h2>
                Your profile
              </h2>
            </div>
          </div>

          <div className="dashboard-profile-card">
            <div className="dashboard-profile-avatar">
              {initials}
            </div>

            <div className="dashboard-profile-info">
              <h3>
                {userName}
              </h3>

              <p>
                {storedUser.email ||
                  "Email not available"}
              </p>

              {storedUser.phone && (
                <p>
                  {storedUser.phone}
                </p>
              )}
            </div>
          </div>
        </section>

        <section
          className="dashboard-section"
          id="settings"
        >
          <div className="dashboard-section-header">
            <div>
              <span className="dashboard-label">
                SETTINGS
              </span>

              <h2>
                Account settings
              </h2>
            </div>
          </div>

          <div className="dashboard-settings-card">
            <div className="dashboard-setting-row">
              <div>
                <h3>
                  Account security
                </h3>

                <p>
                  Keep your EstateLy account secure.
                </p>
              </div>

              <button
                type="button"
                onClick={handleOpenSecurity}
              >
                Manage
              </button>
            </div>

            <div className="dashboard-setting-row">
              <div>
                <h3>
                  Email notifications
                </h3>

                <p>
                  Manage your property notification preferences.
                </p>
              </div>

              <button
                type="button"
                onClick={handleOpenNotifications}
              >
                Manage
              </button>
            </div>
          </div>
        </section>

        <footer className="dashboard-footer">
          <p>
            © 2026 EstateLy. Property discovery made simple.
          </p>
        </footer>
      </main>

      {showNotifications && (
        <div
          className="schedule-modal-overlay"
          onClick={handleCloseNotifications}
        >
          <div
            className="schedule-modal"
            onClick={(event) =>
              event.stopPropagation()
            }
          >
            <button
              type="button"
              className="schedule-modal-close"
              onClick={handleCloseNotifications}
              disabled={notificationSaving}
            >
              <X size={20} />
            </button>

            <span className="section-label">
              EMAIL NOTIFICATIONS
            </span>

            <h2>
              Notification Preferences
            </h2>

            <p>
              Choose which EstateLy email notifications you would like to receive.
            </p>

            <form
              onSubmit={handleSaveNotifications}
              style={{
                display: "flex",
                flexDirection: "column",
                gap: "14px"
              }}
            >
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "10px",
                  padding: "14px",
                  border: "1px solid #e8e3dc",
                  borderRadius: "12px"
                }}
              >
                <Bell size={18} />

                <div style={{ flex: 1 }}>
                  <strong>
                    Visit Confirmations
                  </strong>

                  <p
                    style={{
                      margin: "4px 0 0",
                      fontSize: "13px"
                    }}
                  >
                    Get an email when a property visit is scheduled.
                  </p>
                </div>

                <input
                  type="checkbox"
                  checked={
                    notificationPreferences.visitConfirmations
                  }
                  onChange={() =>
                    handleNotificationChange(
                      "visitConfirmations"
                    )
                  }
                  disabled={notificationSaving}
                />
              </div>

              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "10px",
                  padding: "14px",
                  border: "1px solid #e8e3dc",
                  borderRadius: "12px"
                }}
              >
                <Home size={18} />

                <div style={{ flex: 1 }}>
                  <strong>
                    New Property Alerts
                  </strong>

                  <p
                    style={{
                      margin: "4px 0 0",
                      fontSize: "13px"
                    }}
                  >
                    Receive updates about new properties.
                  </p>
                </div>

                <input
                  type="checkbox"
                  checked={
                    notificationPreferences.newPropertyAlerts
                  }
                  onChange={() =>
                    handleNotificationChange(
                      "newPropertyAlerts"
                    )
                  }
                  disabled={notificationSaving}
                />
              </div>

              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "10px",
                  padding: "14px",
                  border: "1px solid #e8e3dc",
                  borderRadius: "12px"
                }}
              >
                <Heart size={18} />

                <div style={{ flex: 1 }}>
                  <strong>
                    Wishlist Updates
                  </strong>

                  <p
                    style={{
                      margin: "4px 0 0",
                      fontSize: "13px"
                    }}
                  >
                    Get updates related to your saved properties.
                  </p>
                </div>

                <input
                  type="checkbox"
                  checked={
                    notificationPreferences.wishlistUpdates
                  }
                  onChange={() =>
                    handleNotificationChange(
                      "wishlistUpdates"
                    )
                  }
                  disabled={notificationSaving}
                />
              </div>

              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "10px",
                  padding: "14px",
                  border: "1px solid #e8e3dc",
                  borderRadius: "12px"
                }}
              >
                <CalendarDays size={18} />

                <div style={{ flex: 1 }}>
                  <strong>
                    Visit Reminders
                  </strong>

                  <p
                    style={{
                      margin: "4px 0 0",
                      fontSize: "13px"
                    }}
                  >
                    Receive reminders about your scheduled visits.
                  </p>
                </div>

                <input
                  type="checkbox"
                  checked={
                    notificationPreferences.visitReminders
                  }
                  onChange={() =>
                    handleNotificationChange(
                      "visitReminders"
                    )
                  }
                  disabled={notificationSaving}
                />
              </div>

              <button
                type="submit"
                className="schedule-confirm-btn"
                disabled={notificationSaving}
              >
                {notificationSaving
                  ? "Saving Preferences..."
                  : "Save Preferences"}

                {!notificationSaving && (
                  <CheckCircle2 size={18} />
                )}
              </button>
            </form>
          </div>
        </div>
      )}

      {showSecurity && (
        <div
          className="schedule-modal-overlay"
          onClick={handleCloseSecurity}
        >
          <div
            className="schedule-modal"
            onClick={(event) =>
              event.stopPropagation()
            }
          >
            <button
              type="button"
              className="schedule-modal-close"
              onClick={handleCloseSecurity}
              disabled={passwordLoading}
            >
              <X size={20} />
            </button>

            <span className="section-label">
              ACCOUNT SECURITY
            </span>

            <h2>
              Change Password
            </h2>

            <p>
              Update your EstateLy account password
              to keep your account secure.
            </p>

            <form
              onSubmit={handleChangePassword}
              style={{
                display: "flex",
                flexDirection: "column",
                gap: "14px"
              }}
            >
              <label
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "7px"
                }}
              >
                <Mail size={16} />
                Account Email
              </label>

              <input
                type="email"
                value={storedUser.email || ""}
                readOnly
                style={{
                  background: "#f5f5f5",
                  cursor: "not-allowed"
                }}
              />

              <label
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "7px"
                }}
              >
                <Lock size={16} />
                Current Password
              </label>

              <input
                type="password"
                placeholder="Enter current password"
                value={currentPassword}
                onChange={(e) =>
                  setCurrentPassword(
                    e.target.value
                  )
                }
                required
                autoComplete="current-password"
              />

              <label
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "7px"
                }}
              >
                <Lock size={16} />
                New Password
              </label>

              <input
                type="password"
                placeholder="Enter new password"
                value={newPassword}
                onChange={(e) =>
                  setNewPassword(
                    e.target.value
                  )
                }
                required
                minLength={6}
                autoComplete="new-password"
              />

              <label
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "7px"
                }}
              >
                <Lock size={16} />
                Confirm New Password
              </label>

              <input
                type="password"
                placeholder="Confirm new password"
                value={confirmPassword}
                onChange={(e) =>
                  setConfirmPassword(
                    e.target.value
                  )
                }
                required
                minLength={6}
                autoComplete="new-password"
              />

              <button
                type="submit"
                className="schedule-confirm-btn"
                disabled={passwordLoading}
              >
                {passwordLoading
                  ? "Updating Password..."
                  : "Update Password"}

                {!passwordLoading && (
                  <CheckCircle2 size={18} />
                )}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default Dashboard;