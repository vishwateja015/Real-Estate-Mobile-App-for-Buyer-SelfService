import { useEffect, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import {
  BedDouble,
  Bath,
  Maximize,
  MapPin,
  Search,
  X
} from "lucide-react";

function Properties() {
  const [properties, setProperties] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [searchParams, setSearchParams] = useSearchParams();
  const initialSearch = searchParams.get("search") || "";

  const [searchText, setSearchText] = useState(initialSearch);

  useEffect(() => {
    fetch("http://localhost:5000/api/properties")
      .then((response) => {
        if (!response.ok) {
          throw new Error("Failed to fetch properties");
        }

        return response.json();
      })
      .then((data) => {
        setProperties(data);
        setLoading(false);
      })
      .catch((error) => {
        console.error(error);
        setError("Unable to load properties");
        setLoading(false);
      });
  }, []);

  useEffect(() => {
    const searchFromUrl = searchParams.get("search") || "";
    setSearchText(searchFromUrl);
  }, [searchParams]);

  const handleSearch = (e) => {
    const value = e.target.value;

    setSearchText(value);

    if (value.trim()) {
      setSearchParams({
        search: value
      });
    } else {
      setSearchParams({});
    }
  };

  const clearSearch = () => {
    setSearchText("");
    setSearchParams({});
  };

  const filteredProperties = properties.filter((property) => {
    const query = searchText.trim().toLowerCase();

    if (!query) {
      return true;
    }

    return (
      property.title?.toLowerCase().includes(query) ||
      property.location?.toLowerCase().includes(query) ||
      property.type?.toLowerCase().includes(query) ||
      property.price?.toLowerCase().includes(query) ||
      String(property.bedrooms).includes(query) ||
      String(property.bathrooms).includes(query) ||
      property.area?.toLowerCase().includes(query)
    );
  });

  if (loading) {
    return (
      <div className="properties-page">
        <div className="loading-state">
          <h2>Loading properties...</h2>
          <p>Please wait while we fetch the latest properties.</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="properties-page">
        <div className="loading-state">
          <h2>{error}</h2>
          <p>Make sure the EstateLy backend is running.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="properties-page">

      <section className="properties-hero">

        <div className="properties-hero-overlay"></div>

        <div className="properties-hero-content">

          <div>
            <span className="section-label">
              ESTATELY COLLECTION
            </span>

            <h1>Explore Properties</h1>

            <p>
              Discover premium homes and properties available in Hyderabad.
            </p>
          </div>

          <div className="property-count">
            {filteredProperties.length} Properties
          </div>

        </div>

      </section>

      <section className="properties-section">

        <div className="properties-container">

          <div className="properties-section-header">

            <div>
              <span className="section-label">
                FIND YOUR HOME
              </span>

              <h2>Featured Properties</h2>

              <p>
                Explore our collection of premium properties.
              </p>
            </div>

          </div>

          <div className="estate-search-wrapper">

            <div className="estate-search-box">

              <Search size={20} />

              <input
                type="text"
                placeholder="Search by property, location or type..."
                value={searchText}
                onChange={handleSearch}
              />

              {searchText && (
                <button
                  type="button"
                  className="estate-search-clear"
                  onClick={clearSearch}
                  aria-label="Clear search"
                >
                  <X size={18} />
                </button>
              )}

            </div>

          </div>

          {searchText && (
            <div className="search-result-info">
              Showing {filteredProperties.length} result
              {filteredProperties.length !== 1 ? "s" : ""} for
              <strong> "{searchText}"</strong>
            </div>
          )}

          {filteredProperties.length === 0 ? (

            <div className="no-properties-found">

              <Search size={42} />

              <h2>No properties found</h2>

              <p>
                We couldn't find a property matching "{searchText}".
              </p>

              <button
                type="button"
                onClick={clearSearch}
              >
                View All Properties
              </button>

            </div>

          ) : (

            <div className="properties-grid">

              {filteredProperties.map((property) => (

                <div
                  className="property-card"
                  key={property.id}
                >

                  <div className="property-image-wrapper">

                    <img
                      src={property.image}
                      alt={property.title}
                      className="property-image"
                    />

                  </div>

                  <div className="property-card-content">

                    <div className="property-type">
                      {property.type}
                    </div>

                    <h2>
                      {property.title}
                    </h2>

                    <div className="property-location">

                      <MapPin size={16} />

                      <span>
                        {property.location}
                      </span>

                    </div>

                    <div className="property-features">

                      <div>
                        <BedDouble size={17} />
                        <span>
                          {property.bedrooms} Beds
                        </span>
                      </div>

                      <div>
                        <Bath size={17} />
                        <span>
                          {property.bathrooms} Baths
                        </span>
                      </div>

                      <div>
                        <Maximize size={17} />
                        <span>
                          {property.area}
                        </span>
                      </div>

                    </div>

                    <div className="property-card-bottom">

                      <div className="property-price">
                        {property.price}
                      </div>

                      <Link
                        to={`/property/${property.id}`}
                        className="view-property-btn"
                      >
                        View Details
                      </Link>

                    </div>

                  </div>

                </div>

              ))}

            </div>

          )}

        </div>

      </section>

    </div>
  );
}

export default Properties;