import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  User,
  Mail,
  Lock,
  Phone,
  ArrowRight,
  Home
} from "lucide-react";

function Register() {
  const navigate = useNavigate();

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");

  const [loading, setLoading] = useState(false);

  const handleRegister = async (e) => {
    e.preventDefault();

    setLoading(true);

    try {
      const response = await fetch(
        "http://localhost:5000/api/auth/register",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            name,
            email,
            phone,
            password
          })
        }
      );

      const data = await response.json();

      if (!response.ok) {
        alert(data.message || "Registration failed");
        return;
      }

      localStorage.setItem("userId", String(data.user.id));
      localStorage.setItem("token", data.token);
      localStorage.setItem(
        "user",
        JSON.stringify(data.user)
      );

      alert("Registration successful!");

      navigate("/dashboard");

    } catch (error) {
      console.error("Registration error:", error);

      alert(
        "Unable to connect to the server. Make sure the backend is running."
      );

    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-page">

      <div className="auth-image register-image">
        <div className="auth-overlay">

          <Link to="/" className="auth-logo">
            Estate<span>ly</span>
          </Link>

          <div className="auth-quote">

            <h2>
              Your next chapter starts with the right home.
            </h2>

            <p>
              Create your buyer account and start exploring
              properties that match your lifestyle.
            </p>

          </div>

        </div>
      </div>


      <div className="auth-form-area">

        <Link to="/" className="mobile-auth-logo">
          <Home size={18} />
          Estate<span>ly</span>
        </Link>

        <div className="auth-form">

          <span className="section-label">
            GET STARTED
          </span>

          <h1>Create your account</h1>

          <p className="auth-subtitle">
            Join EstateLy and begin your property journey.
          </p>


          <form onSubmit={handleRegister}>

            <label>Full Name</label>

            <div className="input-box">
              <User size={18} />

              <input
                type="text"
                placeholder="Your full name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
              />
            </div>


            <label>Email Address</label>

            <div className="input-box">
              <Mail size={18} />

              <input
                type="email"
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>


            <label>Phone Number</label>

            <div className="input-box">
              <Phone size={18} />

              <input
                type="tel"
                placeholder="+91 XXXXX XXXXX"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                required
              />
            </div>


            <label>Password</label>

            <div className="input-box">
              <Lock size={18} />

              <input
                type="password"
                placeholder="Create a password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>


            <button
              type="submit"
              className="auth-submit"
              disabled={loading}
            >
              {loading ? "Creating Account..." : "Create Account"}

              {!loading && <ArrowRight size={18} />}
            </button>

          </form>


          <p className="register-text">

            Already have an account?

            <Link to="/login">
              {" "}Sign In
            </Link>

          </p>

        </div>

      </div>

    </div>
  );
}

export default Register;