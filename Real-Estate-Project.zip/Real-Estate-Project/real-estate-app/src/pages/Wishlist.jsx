import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  Heart,
  MapPin,
  BedDouble,
  Bath,
  Maximize,
  ArrowRight
} from "lucide-react";

function Wishlist() {
  const [savedProperties, setSavedProperties] = useState([]);
  const [loading, setLoading] = useState(true);

  const loadWishlist = async () => {
    try {
      const userId = localStorage.getItem("userId");

      if (!userId) {
        setSavedProperties([]);
        setLoading(false);
        return;
      }

      const response = await fetch(
        `http://localhost:5000/api/favorites/${userId}`
      );

      if (!response.ok) {
        throw new Error("Failed to load wishlist");
      }

      const data = await response.json();

      setSavedProperties(data);

    } catch (error) {
      console.error("Failed to load wishlist:", error);
      setSavedProperties([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadWishlist();
  }, []);

  const handleRemove = async (propertyId) => {
    try {
      const userId = localStorage.getItem("userId");

      if (!userId) {
        alert("Please login first.");
        return;
      }

      const response = await fetch(
        `http://localhost:5000/api/favorites/${propertyId}`,
        {
          method: "DELETE",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            user_id: userId
          })
        }
      );

      if (!response.ok) {
        throw new Error("Failed to remove property");
      }

      setSavedProperties((current) =>
        current.filter(
          (property) =>
            Number(property.id) !== Number(propertyId)
        )
      );

    } catch (error) {
      console.error("Remove wishlist error:", error);
      alert("Unable to remove property from wishlist.");
    }
  };

  return (
    <div className="wishlist-page">

      <section className="wishlist-header">

        <div>
          <span className="section-label">
            YOUR COLLECTION
          </span>

          <h1>Wishlist</h1>

          <p>
            Properties you have saved for later.
          </p>
        </div>

        <div className="wishlist-count">
          <Heart size={18} />
          {savedProperties.length} Saved
        </div>

      </section>


      <section className="wishlist-content">

        {loading ? (

          <div className="wishlist-empty">

            <div className="wishlist-empty-icon">
              <Heart size={32} />
            </div>

            <h2>Loading wishlist...</h2>

            <p>
              Please wait while we load your saved properties.
            </p>

          </div>

        ) : savedProperties.length === 0 ? (

          <div className="wishlist-empty">

            <div className="wishlist-empty-icon">
              <Heart size={32} />
            </div>

            <h2>Your wishlist is empty</h2>

            <p>
              Save properties you like and they will appear here.
            </p>

            <Link
              to="/properties"
              className="wishlist-browse-btn"
            >
              Browse Properties
              <ArrowRight size={17} />
            </Link>

          </div>

        ) : (

          <div className="wishlist-grid">

            {savedProperties.map((property) => (

              <div
                className="wishlist-card"
                key={property.id}
              >

                <div className="wishlist-image-wrapper">

                  <img
                    src={property.image}
                    alt={property.title}
                  />

                  <button
                    className="wishlist-remove"
                    onClick={() =>
                      handleRemove(property.id)
                    }
                    title="Remove from wishlist"
                  >
                    <Heart
                      size={19}
                      fill="currentColor"
                    />
                  </button>

                </div>


                <div className="wishlist-card-content">

                  <span className="wishlist-property-type">
                    {property.type}
                  </span>

                  <h2>
                    {property.title}
                  </h2>

                  <div className="wishlist-location">
                    <MapPin size={16} />
                    {property.location}
                  </div>


                  <div className="wishlist-features">

                    <span>
                      <BedDouble size={16} />
                      {property.bedrooms} Beds
                    </span>

                    <span>
                      <Bath size={16} />
                      {property.bathrooms} Baths
                    </span>

                    <span>
                      <Maximize size={16} />
                      {property.area}
                    </span>

                  </div>


                  <div className="wishlist-bottom">

                    <strong>
                      {property.price}
                    </strong>

                    <Link
                      to={`/property/${property.id}`}
                      className="wishlist-view-btn"
                    >
                      View Details
                    </Link>

                  </div>

                </div>

              </div>

            ))}

          </div>

        )}

      </section>

    </div>
  );
}

export default Wishlist;