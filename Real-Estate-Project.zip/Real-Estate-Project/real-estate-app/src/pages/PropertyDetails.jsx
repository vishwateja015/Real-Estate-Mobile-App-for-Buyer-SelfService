import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import {
  ArrowLeft,
  MapPin,
  BedDouble,
  Bath,
  Heart,
  Home,
  Car,
  ShieldCheck,
  Dumbbell,
  Wifi,
  Phone,
  Mail,
  CalendarDays,
  CheckCircle,
  X
} from "lucide-react";

function PropertyDetails() {
  const { id } = useParams();

  const [favorite, setFavorite] = useState(false);
  const [showMessage, setShowMessage] = useState(false);
  const [showSchedule, setShowSchedule] = useState(false);
  const [showContact, setShowContact] = useState(false);

  const [visitDate, setVisitDate] = useState("");
  const [visitTime, setVisitTime] = useState("");
  const [scheduleLoading, setScheduleLoading] = useState(false);

  const properties = [
    {
      id: 1,
      title: "Modern Luxury Villa",
      location: "Gachibowli, Hyderabad",
      price: "₹2.45 Cr",
      beds: 4,
      baths: 4,
      area: "3,200 sq.ft",
      type: "Villa",
      image:
        "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1400&q=85"
    },
    {
      id: 2,
      title: "Premium City Apartment",
      location: "Hitech City, Hyderabad",
      price: "₹1.28 Cr",
      beds: 3,
      baths: 3,
      area: "2,100 sq.ft",
      type: "Apartment",
      image:
        "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1400&q=85"
    },
    {
      id: 3,
      title: "Elegant Family Home",
      location: "Kondapur, Hyderabad",
      price: "₹1.85 Cr",
      beds: 3,
      baths: 3,
      area: "2,650 sq.ft",
      type: "House",
      image:
        "https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&w=1400&q=85"
    },
    {
      id: 4,
      title: "Contemporary Sky Villa",
      location: "Jubilee Hills, Hyderabad",
      price: "₹3.20 Cr",
      beds: 4,
      baths: 4,
      area: "3,600 sq.ft",
      type: "Villa",
      image:
        "https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&w=1400&q=85"
    },
    {
      id: 5,
      title: "Luxury Tech Park Apartment",
      location: "Madhapur, Hyderabad",
      price: "₹1.55 Cr",
      beds: 3,
      baths: 3,
      area: "2,350 sq.ft",
      type: "Apartment",
      image:
        "https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?auto=format&fit=crop&w=1400&q=85"
    },
    {
      id: 6,
      title: "Green Valley Residence",
      location: "Manikonda, Hyderabad",
      price: "₹1.72 Cr",
      beds: 3,
      baths: 3,
      area: "2,800 sq.ft",
      type: "House",
      image:
        "https://images.unsplash.com/photo-1600585154526-990dced4db0d?auto=format&fit=crop&w=1400&q=85"
    },
    {
      id: 7,
      title: "Elegant Downtown Apartment",
      location: "Banjara Hills, Hyderabad",
      price: "₹2.10 Cr",
      beds: 3,
      baths: 3,
      area: "2,450 sq.ft",
      type: "Apartment",
      image:
        "https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&w=1400&q=85"
    },
    {
      id: 8,
      title: "Premium Garden Villa",
      location: "Kokapet, Hyderabad",
      price: "₹2.85 Cr",
      beds: 4,
      baths: 5,
      area: "4,100 sq.ft",
      type: "Villa",
      image:
        "https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&w=1400&q=85"
    }
  ];

  const property =
    properties.find((item) => item.id === Number(id)) || properties[0];

  useEffect(() => {
    const checkFavorite = async () => {
      try {
        const userId = localStorage.getItem("userId");

        if (!userId) {
          setFavorite(false);
          return;
        }

        const response = await fetch(
          `http://localhost:5000/api/favorites/${userId}`
        );

        if (!response.ok) {
          throw new Error("Failed to check wishlist");
        }

        const favorites = await response.json();

        const alreadySaved = favorites.some(
          (item) => Number(item.id) === Number(property.id)
        );

        setFavorite(alreadySaved);
      } catch (error) {
        console.error("Failed to check favorite:", error);
        setFavorite(false);
      }
    };

    if (property?.id) {
      checkFavorite();
    }

    const recordPropertyView = async () => {
      const userId = localStorage.getItem("userId");

      if (!userId || !property?.id) {
        return;
      }

      try {
        const response = await fetch(
          "http://localhost:5000/api/property-views",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json"
            },
            body: JSON.stringify({
              user_id: userId,
              property_id: property.id
            })
          }
        );

        if (!response.ok) {
          throw new Error("Failed to record property view");
        }

        console.log("Property view recorded");
      } catch (error) {
        console.error("Failed to record property view:", error);
      }
    };

    recordPropertyView();
  }, [property?.id]);

  const amenities = [
    {
      icon: <Home size={20} />,
      name: "Modern Interior"
    },
    {
      icon: <Car size={20} />,
      name: "Private Parking"
    },
    {
      icon: <ShieldCheck size={20} />,
      name: "24/7 Security"
    },
    {
      icon: <Dumbbell size={20} />,
      name: "Fitness Center"
    },
    {
      icon: <Wifi size={20} />,
      name: "High-Speed WiFi"
    },
    {
      icon: <CheckCircle size={20} />,
      name: "Verified Property"
    }
  ];

  const handleFavorite = async () => {
    try {
      const userId = localStorage.getItem("userId");

      if (!userId) {
        alert("Please login first to save properties.");
        return;
      }

      if (favorite) {
        const response = await fetch(
          `http://localhost:5000/api/favorites/${property.id}`,
          {
            method: "DELETE",
            headers: {
              "Content-Type": "application/json"
            },
            body: JSON.stringify({
              user_id: userId
            })
          }
        );

        if (!response.ok) {
          throw new Error("Failed to remove property");
        }

        setFavorite(false);
      } else {
        const response = await fetch(
          "http://localhost:5000/api/favorites",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json"
            },
            body: JSON.stringify({
              user_id: userId,
              property_id: property.id
            })
          }
        );

        if (!response.ok) {
          const data = await response.json();

          if (response.status === 409) {
            setFavorite(true);
            return;
          }

          throw new Error(
            data.message || "Failed to save property"
          );
        }

        setFavorite(true);
      }
    } catch (error) {
      console.error("Wishlist error:", error);
      alert("Unable to update wishlist.");
    }
  };

  const handleSchedule = async () => {
    const userId = localStorage.getItem("userId");

    if (!userId) {
      alert("Please login first to schedule a visit.");
      return;
    }

    setShowSchedule(true);
  };

  const handleConfirmVisit = async (e) => {
    e.preventDefault();

    const userId = localStorage.getItem("userId");

    if (!userId) {
      alert("Please login first.");
      return;
    }

    if (!visitDate || !visitTime) {
      alert("Please select both date and time.");
      return;
    }

    setScheduleLoading(true);

    try {
      const response = await fetch(
        "http://localhost:5000/api/visits",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            user_id: userId,
            property_id: property.id,
            visit_date: visitDate,
            visit_time: visitTime
          })
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.message || "Failed to schedule visit"
        );
      }

      setShowSchedule(false);
      setVisitDate("");
      setVisitTime("");

      setShowMessage(true);

      setTimeout(() => {
        setShowMessage(false);
      }, 3000);
    } catch (error) {
      console.error("Schedule visit error:", error);

      alert(
        error.message || "Unable to schedule the visit."
      );
    } finally {
      setScheduleLoading(false);
    }
  };

  const handleContactAgent = () => {
    setShowContact(true);
  };

  const closeContact = () => {
    setShowContact(false);
  };

  return (
    <div className="details-page">
      <div className="details-topbar">
        <Link
          to="/properties"
          className="back-link"
        >
          <ArrowLeft size={18} />
          Back to Properties
        </Link>

        <button
          className={`details-heart ${
            favorite ? "favorite-active" : ""
          }`}
          onClick={handleFavorite}
        >
          <Heart
            size={20}
            fill={
              favorite
                ? "currentColor"
                : "none"
            }
          />

          {favorite
            ? "Saved"
            : "Save Property"}
        </button>
      </div>

      <div className="details-image-container">
        <img
          src={property.image}
          alt={property.title}
          className="details-main-image"
        />

        <div className="details-image-tag">
          {property.type}
        </div>
      </div>

      <div className="details-content">
        <div className="details-main">
          <span className="section-label">
            VERIFIED PROPERTY
          </span>

          <h1>{property.title}</h1>

          <p className="details-location">
            <MapPin size={18} />
            {property.location}
          </p>

          <div className="details-price">
            {property.price}
          </div>

          <div className="details-stats">
            <div>
              <BedDouble size={22} />

              <strong>
                {property.beds}
              </strong>

              <span>
                Bedrooms
              </span>
            </div>

            <div>
              <Bath size={22} />

              <strong>
                {property.baths}
              </strong>

              <span>
                Bathrooms
              </span>
            </div>

            <div>
              <Home size={22} />

              <strong>
                {property.area}
              </strong>

              <span>
                Built-up Area
              </span>
            </div>
          </div>

          <div className="details-section">
            <h2>
              About this property
            </h2>

            <p>
              Experience comfortable and modern
              living in this beautiful property
              located in one of the most desirable
              areas of Hyderabad. Designed with
              spacious rooms, quality interiors and
              convenient access to essential
              facilities.
            </p>

            <p>
              The property offers an excellent
              combination of comfort, location and
              lifestyle, making it suitable for
              families looking for a premium home.
            </p>
          </div>

          <div className="details-section">
            <h2>Amenities</h2>

            <div className="amenities-grid">
              {amenities.map(
                (amenity, index) => (
                  <div
                    className="amenity"
                    key={index}
                  >
                    <div className="amenity-icon">
                      {amenity.icon}
                    </div>

                    <span>
                      {amenity.name}
                    </span>
                  </div>
                )
              )}
            </div>
          </div>

          <div className="details-section">
            <h2>Location</h2>

            <div className="map-placeholder">
              <MapPin size={35} />

              <h3>
                {property.location}
              </h3>

              <p>
                Convenient access to schools,
                hospitals, shopping centers and
                major roads.
              </p>
            </div>
          </div>
        </div>

        <aside className="agent-card">
          <div className="agent-top">
            <div className="agent-avatar">
              AR
            </div>

            <div>
              <small>
                PROPERTY CONSULTANT
              </small>

              <h3>
                Arjun Reddy
              </h3>

              <p>
                EstateLy Verified Agent
              </p>
            </div>
          </div>

          <div className="agent-divider"></div>

          <button
            className="schedule-btn"
            onClick={handleSchedule}
          >
            <CalendarDays size={18} />
            Schedule a Visit
          </button>

          <button
            className="contact-btn"
            onClick={handleContactAgent}
          >
            <Phone size={18} />
            Contact Agent
          </button>

          <div className="agent-note">
            <ShieldCheck size={17} />

            <span>
              Your information is safe and will
              only be shared with the property
              consultant.
            </span>
          </div>
        </aside>
      </div>

      {showContact && (
        <div
          onClick={closeContact}
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(0, 0, 0, 0.55)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            padding: "20px",
            zIndex: 9999
          }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            style={{
              width: "100%",
              maxWidth: "420px",
              background: "#ffffff",
              borderRadius: "20px",
              padding: "28px",
              boxSizing: "border-box",
              position: "relative",
              boxShadow: "0 20px 60px rgba(0,0,0,0.25)"
            }}
          >
            <button
              type="button"
              onClick={closeContact}
              style={{
                position: "absolute",
                top: "16px",
                right: "16px",
                width: "36px",
                height: "36px",
                border: "none",
                borderRadius: "50%",
                background: "#f4f4f4",
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                justifyContent: "center"
              }}
            >
              <X size={19} />
            </button>

            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: "15px",
                marginBottom: "24px"
              }}
            >
              <div
                style={{
                  width: "58px",
                  height: "58px",
                  borderRadius: "50%",
                  background: "#b08a4c",
                  color: "#ffffff",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontWeight: "700",
                  fontSize: "18px"
                }}
              >
                AR
              </div>

              <div>
                <span
                  style={{
                    display: "block",
                    fontSize: "11px",
                    color: "#999",
                    fontWeight: "600",
                    letterSpacing: "0.8px",
                    marginBottom: "4px"
                  }}
                >
                  ESTATELY VERIFIED AGENT
                </span>

                <h2
                  style={{
                    margin: 0,
                    fontSize: "22px",
                    color: "#222"
                  }}
                >
                  Arjun Reddy
                </h2>
              </div>
            </div>

            <div
              style={{
                background: "#f8f6f2",
                borderRadius: "14px",
                padding: "16px",
                marginBottom: "20px"
              }}
            >
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "12px",
                  marginBottom: "14px"
                }}
              >
                <Phone
                  size={19}
                  color="#b08a4c"
                />

                <div>
                  <small
                    style={{
                      display: "block",
                      color: "#888",
                      fontSize: "11px",
                      marginBottom: "3px"
                    }}
                  >
                    PHONE
                  </small>

                  <strong
                    style={{
                      color: "#222"
                    }}
                  >
                    +91 98765 43210
                  </strong>
                </div>
              </div>

              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "12px"
                }}
              >
                <Mail
                  size={19}
                  color="#b08a4c"
                />

                <div>
                  <small
                    style={{
                      display: "block",
                      color: "#888",
                      fontSize: "11px",
                      marginBottom: "3px"
                    }}
                  >
                    EMAIL
                  </small>

                  <strong
                    style={{
                      color: "#222",
                      wordBreak: "break-word"
                    }}
                  >
                    arjun@estately.com
                  </strong>
                </div>
              </div>
            </div>

            <p
              style={{
                color: "#777",
                fontSize: "14px",
                lineHeight: "1.6",
                marginBottom: "20px"
              }}
            >
              Contact Arjun for more information
              about this property, availability,
              pricing or to arrange a property visit.
            </p>

            <div
              style={{
                display: "grid",
                gridTemplateColumns: "1fr 1fr",
                gap: "10px"
              }}
            >
              <a
                href="tel:+919876543210"
                style={{
                  textDecoration: "none",
                  background: "#b08a4c",
                  color: "#ffffff",
                  borderRadius: "12px",
                  minHeight: "48px",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: "8px",
                  fontSize: "14px",
                  fontWeight: "600"
                }}
              >
                <Phone size={17} />
                Call Agent
              </a>

              <a
                href="mailto:arjun@estately.com"
                style={{
                  textDecoration: "none",
                  background: "#222",
                  color: "#ffffff",
                  borderRadius: "12px",
                  minHeight: "48px",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: "8px",
                  fontSize: "14px",
                  fontWeight: "600"
                }}
              >
                <Mail size={17} />
                Email Agent
              </a>
            </div>
          </div>
        </div>
      )}

      {showSchedule && (
        <div className="schedule-modal-overlay">
          <div className="schedule-modal">
            <button
              type="button"
              className="schedule-modal-close"
              onClick={() =>
                setShowSchedule(false)
              }
            >
              ×
            </button>

            <span className="section-label">
              PROPERTY VISIT
            </span>

            <h2>
              Schedule a Visit
            </h2>

            <p>
              Choose a convenient date and time
              to visit this property.
            </p>

            <form
              onSubmit={handleConfirmVisit}
            >
              <label>
                Visit Date
              </label>

              <input
                type="date"
                value={visitDate}
                min={
                  new Date()
                    .toISOString()
                    .split("T")[0]
                }
                onChange={(e) =>
                  setVisitDate(e.target.value)
                }
                required
              />

              <label>
                Visit Time
              </label>

              <input
                type="time"
                value={visitTime}
                onChange={(e) =>
                  setVisitTime(e.target.value)
                }
                required
              />

              <button
                type="submit"
                className="schedule-confirm-btn"
                disabled={scheduleLoading}
              >
                {scheduleLoading
                  ? "Scheduling..."
                  : "Confirm Visit"}

                {!scheduleLoading && (
                  <CalendarDays size={18} />
                )}
              </button>
            </form>
          </div>
        </div>
      )}

      {showMessage && (
        <div className="success-message">
          <CheckCircle size={22} />

          <div>
            <strong>
              Visit Request Sent!
            </strong>

            <p>
              Our property consultant will
              contact you soon.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}

export default PropertyDetails;