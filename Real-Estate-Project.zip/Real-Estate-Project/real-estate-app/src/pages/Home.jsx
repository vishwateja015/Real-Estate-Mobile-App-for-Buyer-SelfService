import { useEffect, useState } from "react";

import { Link, useNavigate } from "react-router-dom";

import {
  Search,
  MapPin,
  Home as HomeIcon,
  BedDouble,
  Bath,
  ArrowRight,
  ShieldCheck,
  Clock,
  Heart,
  Star
} from "lucide-react";

function Home() {
  const navigate = useNavigate();

  const [favoriteIds, setFavoriteIds] = useState([]);

  const [searchLocation, setSearchLocation] = useState("");
  const [searchType, setSearchType] = useState("");
  const [searchText, setSearchText] = useState("");

  const properties = [
    {
      id: 1,
      title: "Modern Luxury Villa",
      location: "Gachibowli, Hyderabad",
      price: "₹2.45 Cr",
      beds: 4,
      baths: 4,
      area: "3,200 sq.ft",
      image:
        "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1000&q=80"
    },
    {
      id: 2,
      title: "Premium City Apartment",
      location: "Hitech City, Hyderabad",
      price: "₹1.28 Cr",
      beds: 3,
      baths: 3,
      area: "2,100 sq.ft",
      image:
        "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1000&q=80"
    },
    {
      id: 3,
      title: "Elegant Family Home",
      location: "Kondapur, Hyderabad",
      price: "₹1.85 Cr",
      beds: 3,
      baths: 3,
      area: "2,650 sq.ft",
      image:
        "https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&w=1000&q=80"
    }
  ];

  const locations = [
    {
      name: "Hyderabad",
      properties: "1,250+ Properties"
    },
    {
      name: "Bangalore",
      properties: "980+ Properties"
    },
    {
      name: "Mumbai",
      properties: "850+ Properties"
    },
    {
      name: "Chennai",
      properties: "620+ Properties"
    }
  ];

  useEffect(() => {
    const userId = localStorage.getItem("userId");

    if (!userId) {
      return;
    }

    fetch(`http://localhost:5000/api/favorites/${userId}`)
      .then((response) => {
        if (!response.ok) {
          throw new Error("Failed to load favorites");
        }

        return response.json();
      })
      .then((data) => {
        setFavoriteIds(data.map((property) => Number(property.id)));
      })
      .catch((error) => {
        console.error("Favorite loading error:", error);
      });
  }, []);

  const handleFavorite = async (propertyId) => {
    const userId = localStorage.getItem("userId");

    if (!userId) {
      alert("Please login to save properties.");
      return;
    }

    const isFavorite = favoriteIds.includes(propertyId);

    try {
      if (isFavorite) {
        const response = await fetch(
          `http://localhost:5000/api/favorites/${propertyId}`,
          {
            method: "DELETE",
            headers: {
              "Content-Type": "application/json"
            },
            body: JSON.stringify({
              user_id: userId
            })
          }
        );

        if (!response.ok) {
          throw new Error("Failed to remove favorite");
        }

        setFavoriteIds((current) =>
          current.filter((id) => id !== propertyId)
        );
      } else {
        const response = await fetch(
          "http://localhost:5000/api/favorites",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json"
            },
            body: JSON.stringify({
              user_id: userId,
              property_id: propertyId
            })
          }
        );

        if (!response.ok && response.status !== 409) {
          throw new Error("Failed to save favorite");
        }

        setFavoriteIds((current) => [
          ...current,
          propertyId
        ]);
      }
    } catch (error) {
      console.error("Favorite error:", error);
      alert("Unable to update wishlist. Please try again.");
    }
  };

  const handleHomeSearch = (e) => {
    e.preventDefault();

    const query =
      searchText.trim() ||
      searchType.trim() ||
      searchLocation.trim();

    if (query) {
      navigate(
        `/properties?search=${encodeURIComponent(query)}`
      );
    } else {
      navigate("/properties");
    }
  };

  return (
    <div className="home">

      {/* HERO SECTION */}
      <section className="hero">

        <div className="hero-overlay"></div>

        <div className="hero-content">

          <div className="hero-badge">
            <Star size={15} fill="currentColor" />
            Trusted by 10,000+ Buyers
          </div>

          <h1>
            Find a place
            <br />
            <span>you'll love to live.</span>
          </h1>

          <p>
            Discover premium homes, apartments and properties
            that match your lifestyle and budget.
          </p>

          {/* SEARCH BOX */}
          <form
            className="home-property-search"
            onSubmit={handleHomeSearch}
          >

            <div className="home-search-field">

              <MapPin size={20} />

              <div>
                <small>Location</small>

                <select
                  value={searchLocation}
                  onChange={(e) =>
                    setSearchLocation(e.target.value)
                  }
                >
                  <option value="">
                    Any Location
                  </option>

                  <option value="Hyderabad">
                    Hyderabad
                  </option>

                  <option value="Gachibowli">
                    Gachibowli
                  </option>

                  <option value="Hitech City">
                    Hitech City
                  </option>

                  <option value="Kondapur">
                    Kondapur
                  </option>
                </select>
              </div>

            </div>

            <div className="home-search-field">

              <HomeIcon size={20} />

              <div>
                <small>Property Type</small>

                <select
                  value={searchType}
                  onChange={(e) =>
                    setSearchType(e.target.value)
                  }
                >
                  <option value="">
                    All Properties
                  </option>

                  <option value="Villa">
                    Villa
                  </option>

                  <option value="Apartment">
                    Apartment
                  </option>

                  <option value="House">
                    House
                  </option>
                </select>
              </div>

            </div>

            <div className="home-search-field">

              <Search size={20} />

              <div>
                <small>Property Name</small>

                <input
                  type="text"
                  placeholder="Search property..."
                  value={searchText}
                  onChange={(e) =>
                    setSearchText(e.target.value)
                  }
                />
              </div>

            </div>

            <button
              type="submit"
              className="home-search-button"
            >
              Search
              <Search size={18} />
            </button>

          </form>

        </div>
      </section>


      {/* FEATURED PROPERTIES */}
      <section className="section featured">

        <div className="section-heading">

          <div>

            <span className="section-label">
              EXPLORE PROPERTIES
            </span>

            <h2>Featured Properties</h2>

            <p>
              Handpicked properties selected for you.
            </p>

          </div>

          <Link
            to="/properties"
            className="view-all"
          >
            View All
            <ArrowRight size={18} />
          </Link>

        </div>


        <div className="property-grid">

          {properties.map((property) => (

            <div
              className="property-card"
              key={property.id}
            >

              <div className="property-image">

                <Link to={`/property/${property.id}`}>

                  <img
                    src={property.image}
                    alt={property.title}
                  />

                </Link>

                <button
                  type="button"
                  className={`heart-btn ${
                    favoriteIds.includes(property.id)
                      ? "favorite-active"
                      : ""
                  }`}
                  onClick={() =>
                    handleFavorite(property.id)
                  }
                  aria-label={
                    favoriteIds.includes(property.id)
                      ? "Remove from wishlist"
                      : "Add to wishlist"
                  }
                >

                  <Heart
                    size={19}
                    fill={
                      favoriteIds.includes(property.id)
                        ? "currentColor"
                        : "none"
                    }
                  />

                </button>

                <span className="featured-tag">
                  Featured
                </span>

              </div>


              <Link
                to={`/property/${property.id}`}
                className="home-property-link"
              >

                <div className="property-info">

                  <div className="property-price">
                    {property.price}
                  </div>

                  <h3>{property.title}</h3>

                  <p className="property-location">

                    <MapPin size={15} />

                    {property.location}

                  </p>

                  <div className="property-details">

                    <span>
                      <BedDouble size={17} />
                      {property.beds} Beds
                    </span>

                    <span>
                      <Bath size={17} />
                      {property.baths} Baths
                    </span>

                    <span>
                      {property.area}
                    </span>

                  </div>

                </div>

              </Link>

            </div>

          ))}

        </div>

      </section>


      {/* LOCATIONS */}
      <section
        className="locations-section"
        id="locations"
      >

        <div className="section-heading center">

          <span className="section-label">
            TOP LOCATIONS
          </span>

          <h2>Explore Popular Cities</h2>

          <p>
            Find your perfect property in India's most
            desirable locations.
          </p>

        </div>


        <div className="locations-grid">

          {locations.map((location) => (

            <div
              className="location-card"
              key={location.name}
            >

              <div className="location-icon">
                <MapPin size={23} />
              </div>

              <div>

                <h3>{location.name}</h3>

                <p>{location.properties}</p>

              </div>

              <ArrowRight size={19} />

            </div>

          ))}

        </div>

      </section>


      {/* WHY CHOOSE US */}
      <section
        className="section why-us"
        id="about"
      >

        <div className="section-heading center">

          <span className="section-label">
            WHY ESTATELY
          </span>

          <h2>
            Everything You Need to Buy With Confidence
          </h2>

          <p>
            We make property buying simple, transparent and
            stress-free.
          </p>

        </div>


        <div className="benefits-grid">

          <div className="benefit-card">

            <div className="benefit-icon">
              <Search size={24} />
            </div>

            <h3>Easy Property Search</h3>

            <p>
              Quickly discover properties using smart search
              and powerful filters.
            </p>

          </div>


          <div className="benefit-card">

            <div className="benefit-icon">
              <ShieldCheck size={24} />
            </div>

            <h3>Verified Properties</h3>

            <p>
              Browse trusted property listings with reliable
              information.
            </p>

          </div>


          <div className="benefit-card">

            <div className="benefit-icon">
              <Clock size={24} />
            </div>

            <h3>Schedule Visits</h3>

            <p>
              Choose a convenient time and schedule your
              property visit easily.
            </p>

          </div>

        </div>

      </section>


      {/* CTA */}
      <section className="cta-section">

        <div>

          <span className="section-label">
            START YOUR JOURNEY
          </span>

          <h2>
            Your dream home
            <br />
            is waiting for you.
          </h2>

          <p>
            Explore thousands of properties and find the
            perfect place to call home.
          </p>

          <Link
            to="/properties"
            className="cta-btn"
          >
            Explore Properties
            <ArrowRight size={18} />
          </Link>

        </div>

      </section>

    </div>
  );
}

export default Home;