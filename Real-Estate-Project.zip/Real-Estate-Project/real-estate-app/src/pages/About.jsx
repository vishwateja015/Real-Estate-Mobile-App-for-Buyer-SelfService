function About() {
  return (
    <div className="about-page">
      <div className="about-hero">
        <div className="about-container">
          <span className="about-label">ABOUT ESTATELY</span>

          <h1>
            Find a place that
            <span> feels like home.</span>
          </h1>

          <p>
            EstateLy is a modern real-estate platform designed to make
            discovering, saving, and visiting properties simple and convenient.
          </p>
        </div>
      </div>

      <div className="about-container about-content">

        <div className="about-section">
          <span className="about-label">WHAT WE OFFER</span>

          <h2>Everything you need to find your next home.</h2>

          <p>
            Explore properties, view detailed information, save your
            favorites, and schedule property visits — all from one place.
          </p>
        </div>

        <div className="about-features">

          <div className="about-card">
            <div className="about-icon">🏠</div>
            <h3>Explore Properties</h3>
            <p>
              Browse available properties with their price, location,
              bedrooms, bathrooms and area.
            </p>
          </div>

          <div className="about-card">
            <div className="about-icon">❤️</div>
            <h3>Save Favorites</h3>
            <p>
              Save properties you like and easily access them later from
              your Wishlist.
            </p>
          </div>

          <div className="about-card">
            <div className="about-icon">📅</div>
            <h3>Schedule Visits</h3>
            <p>
              Choose a convenient date and time to schedule a visit to
              your selected property.
            </p>
          </div>

        </div>

        <div className="about-bottom">

          <div>
            <span className="about-label">ESTATELY</span>
            <h2>Property discovery made simple.</h2>
          </div>

          <p>
            EstateLy brings property discovery and visit scheduling together
            in one easy-to-use platform.
          </p>

        </div>

      </div>
    </div>
  );
}

export default About;