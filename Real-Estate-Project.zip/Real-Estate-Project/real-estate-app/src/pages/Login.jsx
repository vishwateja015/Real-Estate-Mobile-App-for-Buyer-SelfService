import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Mail, Lock, ArrowRight, Home } from "lucide-react";

function Login() {
  const navigate = useNavigate();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e) => {
    e.preventDefault();

    setLoading(true);

    try {
      const response = await fetch(
        "http://localhost:5000/api/auth/login",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            email,
            password
          })
        }
      );

      const data = await response.json();

      if (!response.ok) {
        alert(data.message || "Login failed");
        return;
      }

      localStorage.setItem("userId", String(data.user.id));
      localStorage.setItem("token", data.token);
      localStorage.setItem(
        "user",
        JSON.stringify(data.user)
      );

      alert("Login successful!");

      navigate("/dashboard");

    } catch (error) {
      console.error("Login error:", error);

      alert(
        "Unable to connect to the server. Make sure the backend is running."
      );

    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-page">

      <div className="auth-image">
        <div className="auth-overlay">

          <Link to="/" className="auth-logo">
            Estate<span>ly</span>
          </Link>

          <div className="auth-quote">

            <h2>
              Find a place you'll love to call home.
            </h2>

            <p>
              Explore beautiful properties and manage your
              home-buying journey in one place.
            </p>

          </div>

        </div>
      </div>


      <div className="auth-form-area">

        <Link to="/" className="mobile-auth-logo">
          <Home size={18} />
          Estate<span>ly</span>
        </Link>

        <div className="auth-form">

          <span className="section-label">
            WELCOME BACK
          </span>

          <h1>Sign in to EstateLy</h1>

          <p className="auth-subtitle">
            Access your saved properties and scheduled visits.
          </p>


          <form onSubmit={handleLogin}>

            <label>Email Address</label>

            <div className="input-box">

              <Mail size={18} />

              <input
                type="email"
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />

            </div>


            <label>Password</label>

            <div className="input-box">

              <Lock size={18} />

              <input
                type="password"
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />

            </div>


            <div className="form-options">

              <label className="remember">

                <input type="checkbox" />

                Remember me

              </label>


              <button
                type="button"
                className="forgot-btn"
              >
                Forgot Password?
              </button>

            </div>


            <button
              type="submit"
              className="auth-submit"
              disabled={loading}
            >

              {loading ? "Signing In..." : "Sign In"}

              {!loading && <ArrowRight size={18} />}

            </button>

          </form>


          <div className="auth-divider">
            <span>OR</span>
          </div>


          <p className="register-text">

            Don't have an account?

            <Link to="/register">
              {" "}Create Account
            </Link>

          </p>

        </div>

      </div>

    </div>
  );
}

export default Login;