const express = require("express");
const router = express.Router();

const pool = require("../config/db");

router.post("/", async (req, res) => {
  try {
    const { user_id, property_id } = req.body;

    if (!user_id || !property_id) {
      return res.status(400).json({
        message: "user_id and property_id are required"
      });
    }

    await pool.query(
      `INSERT INTO property_views
       (user_id, property_id)
       VALUES (?, ?)
       ON DUPLICATE KEY UPDATE viewed_at = CURRENT_TIMESTAMP`,
      [user_id, property_id]
    );

    res.status(201).json({
      message: "Property view recorded"
    });

  } catch (error) {
    console.error("Property view error:", error);

    res.status(500).json({
      message: "Failed to record property view",
      error: error.message
    });
  }
});

router.get("/:userId/count", async (req, res) => {
  try {
    const { userId } = req.params;

    const [rows] = await pool.query(
      `SELECT COUNT(*) AS count
       FROM property_views
       WHERE user_id = ?`,
      [userId]
    );

    res.json({
      count: rows[0].count
    });

  } catch (error) {
    console.error("Property view count error:", error);

    res.status(500).json({
      message: "Failed to load property view count",
      error: error.message
    });
  }
});

module.exports = router;