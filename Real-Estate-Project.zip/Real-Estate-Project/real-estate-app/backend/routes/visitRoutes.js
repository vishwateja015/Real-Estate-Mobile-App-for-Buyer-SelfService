const express = require("express");
const router = express.Router();

const pool = require("../config/db");

router.post("/", async (req, res) => {
  try {
    const {
      user_id,
      property_id,
      visit_date,
      visit_time
    } = req.body;

    if (
      !user_id ||
      !property_id ||
      !visit_date ||
      !visit_time
    ) {
      return res.status(400).json({
        message:
          "user_id, property_id, visit_date and visit_time are required"
      });
    }

    await pool.query(
      `INSERT INTO visits
       (user_id, property_id, visit_date, visit_time)
       VALUES (?, ?, ?, ?)`,
      [
        user_id,
        property_id,
        visit_date,
        visit_time
      ]
    );

    res.status(201).json({
      message: "Visit scheduled successfully"
    });

  } catch (error) {
    console.error("Visit error:", error);

    res.status(500).json({
      message: "Failed to schedule visit",
      error: error.message
    });
  }
});


router.get("/:userId", async (req, res) => {
  try {
    const { userId } = req.params;

    const [rows] = await pool.query(
      `SELECT
        visits.id,
        visits.visit_date,
        visits.visit_time,
        visits.status,
        properties.id AS property_id,
        properties.title,
        properties.location,
        properties.price,
        properties.image
       FROM visits
       INNER JOIN properties
       ON visits.property_id = properties.id
       WHERE visits.user_id = ?
       ORDER BY visits.visit_date ASC, visits.visit_time ASC`,
      [userId]
    );

    res.json(rows);

  } catch (error) {
    console.error("Visit loading error:", error);

    res.status(500).json({
      message: "Failed to load visits",
      error: error.message
    });
  }
});


module.exports = router;