const express = require("express");
const router = express.Router();

const pool = require("../config/db");


// Add property to favorites
router.post("/", async (req, res) => {
  try {
    const { user_id, property_id } = req.body;

    if (!user_id || !property_id) {
      return res.status(400).json({
        message: "user_id and property_id are required"
      });
    }

    await pool.query(
      `INSERT INTO favorites (user_id, property_id)
       VALUES (?, ?)`,
      [user_id, property_id]
    );

    res.status(201).json({
      message: "Property added to wishlist ❤️"
    });

  } catch (error) {

    if (error.code === "ER_DUP_ENTRY") {
      return res.status(409).json({
        message: "Property is already in wishlist"
      });
    }

    console.error(error);

    res.status(500).json({
      message: "Failed to add property to wishlist",
      error: error.message
    });
  }
});


// Get user's wishlist
router.get("/:userId", async (req, res) => {
  try {

    const { userId } = req.params;

    const [rows] = await pool.query(
      `SELECT 
        properties.*
       FROM favorites
       INNER JOIN properties
       ON favorites.property_id = properties.id
       WHERE favorites.user_id = ?
       ORDER BY favorites.created_at DESC`,
      [userId]
    );

    res.json(rows);

  } catch (error) {

    console.error(error);

    res.status(500).json({
      message: "Failed to load wishlist",
      error: error.message
    });
  }
});


// Remove property from wishlist
router.delete("/:propertyId", async (req, res) => {
  try {

    const { propertyId } = req.params;
    const { user_id } = req.body;

    await pool.query(
      `DELETE FROM favorites
       WHERE user_id = ? AND property_id = ?`,
      [user_id, propertyId]
    );

    res.json({
      message: "Property removed from wishlist"
    });

  } catch (error) {

    console.error(error);

    res.status(500).json({
      message: "Failed to remove property",
      error: error.message
    });
  }
});


module.exports = router;