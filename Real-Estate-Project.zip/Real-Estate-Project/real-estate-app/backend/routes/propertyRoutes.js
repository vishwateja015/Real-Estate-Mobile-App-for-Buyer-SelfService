const express = require("express");
const pool = require("../config/db");

const router = express.Router();


// Get all properties
router.get("/", async (req, res) => {
  try {
    const [properties] = await pool.query(
      "SELECT * FROM properties ORDER BY id DESC"
    );

    res.json(properties);

  } catch (error) {
    console.error("Properties error:", error);

    res.status(500).json({
      message: "Failed to fetch properties",
      error: error.message
    });
  }
});


// Get property by ID
router.get("/:id", async (req, res) => {
  try {
    const { id } = req.params;

    const [properties] = await pool.query(
      "SELECT * FROM properties WHERE id = ?",
      [id]
    );

    if (properties.length === 0) {
      return res.status(404).json({
        message: "Property not found"
      });
    }

    res.json(properties[0]);

  } catch (error) {
    console.error("Property error:", error);

    res.status(500).json({
      message: "Failed to fetch property",
      error: error.message
    });
  }
});


module.exports = router;