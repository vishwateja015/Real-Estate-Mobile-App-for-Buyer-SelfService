const express = require("express");
const cors = require("cors");
require("dotenv").config();

const pool = require("./config/db");
const authRoutes = require("./routes/authRoutes");
const propertyRoutes = require("./routes/propertyRoutes");
const favoriteRoutes = require("./routes/favoriteRoutes");
const visitRoutes = require("./routes/visitRoutes");
const propertyViewRoutes = require("./routes/propertyViewRoutes");

const app = express();

const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());


// Authentication routes
app.use("/api/auth", authRoutes);
app.use("/api/properties", propertyRoutes);
app.use("/api/favorites", favoriteRoutes);
app.use("/api/visits", visitRoutes);
app.use("/api/property-views", propertyViewRoutes);


// Home route
app.get("/", (req, res) => {
  res.json({
    message: "EstateLy Backend is running 🚀"
  });
});


// Test MySQL connection
app.get("/api/test-db", async (req, res) => {
  try {
    const [rows] = await pool.query(
      "SELECT 1 AS result"
    );

    res.json({
      message: "MySQL connection successful ✅",
      database: rows
    });

  } catch (error) {
    console.error("Database error:", error);

    res.status(500).json({
      message: "MySQL connection failed ❌",
      error: error.message
    });
  }
});


app.listen(PORT, () => {
  console.log(
    `EstateLy Backend running at http://localhost:${PORT}`
  );
});